﻿using cv7.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;

namespace cv7.Controllers
{
    public class ProductController : Controller
    {
        private ProductService productService;
        private ShoppingCartService cart;
        public ProductController(ProductService productService, ShoppingCartService shoppingCartService)
        {
            this.productService = productService;
            this.cart = shoppingCartService;
        }

        public IActionResult Index(/*[FromServices]ProductService productService*/)
        {
            var products = productService.List();
            ViewBag.Products = products;
            // ViewData["Products"] = products;
            return View();
        }

        public IActionResult Detail(int id, int a, string b)
        {
            var product = productService.Get(id);
            if(product == null)
            {
                return NotFound();
            }
            ViewBag.Product = product;
            return View();
        }

        public IActionResult AddToCart(int id)
        {
            var product = productService.Get(id);
            this.cart.Add(product);
            return RedirectToAction("Detail", new { id = id });
        }

        public override void OnActionExecuting(ActionExecutingContext context)
        {
            ViewBag.ProductCount = cart.Count;
        }
    }
}
