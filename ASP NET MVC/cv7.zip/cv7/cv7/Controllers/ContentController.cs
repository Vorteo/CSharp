﻿using Microsoft.AspNetCore.Mvc;

namespace cv7.Controllers
{
    public class ContentController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
