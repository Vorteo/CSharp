﻿using cv7.Models;
using Microsoft.AspNetCore.Mvc;

namespace cv7.Controllers
{
    public class ShoppingCartController : Controller
    {
        public IActionResult Index()
        {
            return View(/*new ShoppingCartForm()
            {
                Name = "Tonda"
            }*/);
        }

        [HttpPost]
        public IActionResult Index(ShoppingCartForm form)
        {
            if(ModelState.IsValid)
            {
                // TODO uložit objednavku
                return RedirectToAction("Done");
            }
            return View();
        }

        public IActionResult Done()
        {
            return View();
        }

        public IActionResult GetProducts([FromServices] ShoppingCartService cart)
        {
            return new JsonResult(cart.List());
        }


    }
}
