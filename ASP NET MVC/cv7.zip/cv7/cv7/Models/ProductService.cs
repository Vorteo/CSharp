﻿namespace cv7.Models
{
    public class ProductService
    {
        private List<Product> products = Product.GetProducts();

        public List<Product> List() { return products; }

        public Product? Get(int id) {
            return products.FirstOrDefault(x => x.Id == id); 
        }
    }
}
