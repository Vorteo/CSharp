﻿namespace cv7.Models
{
    public class ShoppingCartService
    {
        private List<Product> products = new List<Product>();

        public void Add(Product product)
        {
            products.Add(product);
        }
        public List<Product> List() { return products; }

        public int Count { get { return products.Count; } }
    }
}
