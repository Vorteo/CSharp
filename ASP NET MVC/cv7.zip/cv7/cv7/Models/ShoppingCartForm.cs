﻿using System.ComponentModel.DataAnnotations;

namespace cv7.Models
{
    public class ShoppingCartForm
    {
        [Display(Name = "Jméno")]
        public string? Name { get; set; }
        [Display(Name = "Email")]
        [EmailAddress(ErrorMessage = " Email má špatný formát.")]
        public string Email { get; set; }
        [Display(Name = "Věk")]
        [Required(ErrorMessage = " Věk je povinný.")]
        [Range(1,120, ErrorMessage = " Věk musí být v rozmezí 1 - 120.")]
        public int? Age { get; set; }
    }
}
