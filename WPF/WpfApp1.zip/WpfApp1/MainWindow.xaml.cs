﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public ObservableCollection<Customer> Customers { get; set; }
        public MainWindow()
        {
            InitializeComponent();

            this.Customers = new ObservableCollection<Customer>(Customer.GetCustomers());

            this.DataContext = this;

            // mujGrid.ItemsSource = Customers;

            /*
            Button btn = new Button();
            btn.Content = "klikni";
            btn.Click += Btn_Click;
            this.Content = btn;
            */
        }

        private void AddCustomer(object sender, RoutedEventArgs e)
        {
            Window1 w = new Window1();
            // w.Show();
            w.OnSaveCustomer += x => this.Customers.Add(x);
            w.ShowDialog();

            /*
            this.Customers.Add(new Customer()
            {
                Id = 5,
                FirstName = "Martin",
                LastName = "Kaleta",
                Age = 23,
            });
            */

        }

        private void RemoveCustomer(object sender, RoutedEventArgs e)
        {
            Button btn = (Button)sender;
            Customer c = (Customer)btn.DataContext;
            this.Customers.Remove(c);

        }

        private void AnonymizeCustomer(object sender, RoutedEventArgs e)
        {
            Button btn = (Button)sender;
            Customer c = (Customer)btn.DataContext;
            c.FirstName = "****";
            c.LastName = "****";

            
        }
    }
}
