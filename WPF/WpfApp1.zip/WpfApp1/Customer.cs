using System.Collections.Generic;
using System.ComponentModel;

public class Customer : INotifyPropertyChanged
    {
        public int Id { get; set; }

        private string firstName;
        public string FirstName { 
            get { return firstName; }
            set { SetField(ref firstName, value, nameof(FirstName));} 
        }
        private string lastName;
        public string LastName { 
            get { return lastName; }
            set { SetField(ref lastName, value, nameof(LastName)); } }
        public int Age { get; set; }

    private void SetField<T>(ref T field, T value, string propName)
    {
        field = value;
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propName));
    }

    public event PropertyChangedEventHandler? PropertyChanged;

    public static List<Customer> GetCustomers()
        {
            return new List<Customer>() { 
                new Customer()
                {
                    Id = 1,
                    FirstName = "Jan",
                    LastName = "Novák",
                    Age = 40
                },
                new Customer()
                {
                    Id = 2,
                    FirstName = "Zuzana",
                    LastName = "Báňská",
                    Age = 32
                },
                new Customer()
                {
                    Id = 3,
                    FirstName = "Petra",
                    LastName = "Ostravská",
                    Age = 15
                },
                new Customer()
                {
                    Id = 4,
                    FirstName = "Karel",
                    LastName = "Svoboda",
                    Age = 60
                }
            };
        }

    }