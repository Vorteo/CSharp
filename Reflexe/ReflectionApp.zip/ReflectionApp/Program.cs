﻿using MyLib.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;


namespace ReflectionApp
{
    public class Program
    {
        public static void Main(string[] args)
        {
            string path = "../../../../MyLib/bin/Debug/net6.0/MyLib.dll";

            Assembly assembly = Assembly.LoadFile(Path.GetFullPath(path));

            Type customerType = assembly.GetType("MyLib.Models.Customer");

            object obj = Activator.CreateInstance(customerType);

            var propInfo = customerType.GetProperty("Name");
            propInfo.SetValue(obj, "Martin");

            string name = (string)propInfo.GetValue(obj);
            
            /*
            foreach(var property in customerType.GetProperties())
            {
                Console.WriteLine(property.Name + " " + property.PropertyType);
            }
            */
            foreach(var field in customerType.GetFields(BindingFlags.Instance | BindingFlags.NonPublic))
            {
                Console.WriteLine(field.Name);
            }

            foreach (var field in customerType.GetMethods())
            {
                Console.WriteLine(field.Name);
            }

            Customer c = new Customer()
            {
                Name = "Martin"
            };
            var customT = c.GetType();


            foreach (var attr in customerType.GetCustomAttributes<Table>())
            {
                
                    
                Console.WriteLine(attr.TableName);
            }


            /*
            Type[] types = assembly.GetTypes();
            foreach(var type in types)
            {
                Console.WriteLine(type.FullName);
            }
            */

            //Type controllerType = assembly.GetType("MyLib.Controllers.CustomerController");


            //MethodInfo mi = controllerType.GetMethod("List");

            //object obj = assembly.CreateInstance("MyLib.Controllers.CustomerController");
            /* Zpusoby zapisu vytvoreni instance 
            object obj1 = controllerType.Assembly.CreateInstance(controllerType.FullName);

            object obj3 = Activator.CreateInstance(controllerType, new object[] {1, "Martin", true});
            */

            //string val = (string)mi.Invoke(obj, new object[] {2});

            //Console.WriteLine(val);

            /*
            foreach(var method in controller.GetMethods(BindingFlags.NonPublic | BindingFlags.Instance))
            {
                Console.WriteLine(method.Name + " " + method.ReturnType);
            }
            */



        }
        private static void Old()
        {
            
            string path = "../../../../MyLib/bin/Debug/net6.0/MyLib.dll";

            Assembly assembly = Assembly.LoadFile(Path.GetFullPath(path));

            Console.WriteLine(assembly.FullName);


            string url = "/Customer/List?limit=2";
            List<string> res = url.Split('?').ToList();

            string[] leftP = res[0].Split('/');
            string[] rightP = res[1].Split('&');

            string controllerName = leftP[1] + "Controller";
            string methodName = leftP[2];

            Dictionary<string, string> queryParams = rightP.Select(x => x.Split('=', 2)).ToDictionary(x => x[0], y => y[1]);

            Type controllerType = assembly.GetType("MyLib.Controllers." + controllerName);

            if(controllerType == null)
            {
                Console.WriteLine("Stranka neexistuje");
            }

            MethodInfo mi = controllerType.GetMethod(methodName);

            object obj = Activator.CreateInstance(controllerType);

            List<object> arguments = new List<object>();

            foreach(var paramInfo in mi.GetParameters())
            {
                Type t = paramInfo.ParameterType;
                string parVal = queryParams[paramInfo.Name];

                if(t == typeof(int))
                {
                    arguments.Add(int.Parse(parVal));
                }
                else
                {
                    arguments.Add(parVal);
                }
            }
            
        }
    }
}