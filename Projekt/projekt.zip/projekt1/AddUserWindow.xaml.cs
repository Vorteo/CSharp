﻿using projekt1.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace projekt1
{
    public delegate void SaveUser(User u);
    public partial class AddUserWindow : Window
    {
        public User User { get; set; } = new User();
        public event SaveUser OnSaveUser;
        public AddUserWindow()
        {
            InitializeComponent();
            this.DataContext = this.User;
        }

        private async void Create(object sender, RoutedEventArgs e)
        {
            if(firstNameBox.Text != "" && lastNameBox.Text != "" && phoneBox.Text != "" && emailBox.Text != "" && streetBox.Text != "" && cityBox.Text != "" && postalcodeBox.Text != "")
            {
                User user = new User()
                {
                    fName = firstNameBox.Text,
                    lName = lastNameBox.Text,
                    email = emailBox.Text,
                    phone = phoneBox.Text,
                    password = DateTime.Now.ToString(),
                };

                if(UserTypesComboBox.SelectedIndex >= 0)
                {
                    user.type = UserTypesComboBox.SelectedIndex + 1;
                }

                bool cantCreate = await user.CheckUser();
                if(cantCreate)
                {
                    Address address = new Address()
                    {
                        street = streetBox.Text,
                        city = cityBox.Text,
                        postalcode = postalcodeBox.Text,
                    };

                    bool addr = address.Check();
                    if(addr)
                    {
                        await address.Insert();
                        user.addressId = (int)address.id;
                        await user.Insert();

                        this.User = user;

                        MessageBox.Show("Uživatel vytvořen.");
                        this.OnSaveUser?.Invoke(this.User);
                        this.Close();
                        return;
                    }
                }
            }
            MessageBox.Show("Nepovedlo se vytvořit uživatele. Zkontrolujte své údaje.");
        }
    }
}
