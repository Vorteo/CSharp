﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Documents;

namespace projekt1
{
    class PrimaryKeyAttribute : Attribute
    {
        public bool Skip { get; set; } = false;
    }

    class ForeignKeyAttribute : Attribute
    {
        public bool Skip { get; set; } = false;
    }

    class TableAttribute : Attribute
    {
        public string Name { get; set; }
    }

}
