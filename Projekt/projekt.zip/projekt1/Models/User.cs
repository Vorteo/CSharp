﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace projekt1.Models
{
    [Table(Name = "User")]
    public class User : INotifyPropertyChanged
    {
        [PrimaryKey(Skip = true)]
        public int id { get; set; }

        private string fname;
        public string fName {
            get { return fname; }
            set { SetField(ref fname, value, nameof(fName)); } 
        }

        private string lname;
        public string lName {
            get { return lname; } 
            set {SetField(ref lname, value, nameof(lName)); } 
        }

        private string phonenumber;
        public string phone {
            get { return phonenumber; } 
            set { SetField(ref phonenumber, value, nameof(phone)); } 
        }

        private string Email;
        public string email {
            get {return Email; } 
            set { SetField(ref Email, value, nameof(email)); }
        }

        public string password { get; set; }

        [ForeignKey]
        public int addressId { get; set; }

        private int Type;
        public int type {
            get {return Type; } 
            set { SetField(ref Type, value, nameof(type)); } 
        }

        private void SetField<T>(ref T field, T value, string propName)
        {
            field = value;
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propName));
        }

        public event PropertyChangedEventHandler? PropertyChanged;

        public async Task<bool> CheckLogin()
        {
            var user = await ORM.Select<User>(Database.GetDatabase().connection, "SELECT * FROM User WHERE email = @0", this.email);

            if (user == null)
            {
                return false;
            }

            if (this.password == user[0].password)
            {
                this.password = user[0].password;
                this.phone = user[0].phone;
                this.id = user[0].id;
                this.email = user[0].email;
                this.fName = user[0].fName;
                this.lName = user[0].lName;
                this.type = user[0].type;
                this.addressId = user[0].addressId;

                return true;
            }

            return false;
        }
        public  async Task<bool> CheckUser()
        {
            string regex = @"^[a-z0-9\.\-]+@[a-z0-9\.\-]+\.[a-z]{2,3}$";
            Regex reg = new Regex(regex, RegexOptions.IgnoreCase | RegexOptions.Compiled);

            if (!reg.IsMatch(email))
            {
                return false;
            }

            if(phone.Length != 15)
            {
                return false;
            }

            int space = 0;
            for (int i = 0; i < phone.Length; i++)
            {
                if (phone[i] == ' ')
                {
                    space++;
                }
            }

            if (space != 3)
            {
                return false;
            }


            var sameEmail = await ORM.Select<User>(Database.GetDatabase().connection, "SELECT * FROM User WHERE email = @0", email);
            if (sameEmail != null)
            {
                return false;
            }

            return true;

        }
        public static async Task<List<User>> GetUsers()
        {
            return await ORM.Select<User>(Database.GetDatabase().connection, "SELECT * FROM User", new object[0]);
        }

        public async Task Insert()
        {
            await ORM.Insert(Database.GetDatabase().connection, this);
        }
    }

}
