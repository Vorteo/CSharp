﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace projekt1.Models
{
    [Table(Name = "Reservation")]
    public class Reservation
    {
        [PrimaryKey(Skip = true)]
        public int id { get; set; }
        public string checkInDate { get; set; }
        public string checkOutDate { get; set;}
        public string state { get; set; }
        public double totalPrice { get; set; }
        [ForeignKey]
        public int roomId { get; set; }
        [ForeignKey]
        public int userId { get; set; }
    }
}
