﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace projekt1.Models
{
    [Table(Name = "Availability")]
    public class Availability
    {
        [PrimaryKey(Skip = true)]
        public int id {  get; set; }
        [ForeignKey]
        public int roomId { get; set; }
        public string date { get; set; }
        public int available { get; set; } 
    }
}
