﻿using projekt1.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace projekt1
{
    /// <summary>
    /// Interakční logika pro AddRoomDates.xaml
    /// </summary>
    public partial class AddRoomDates : Window
    {
        List<Room> rooms = new List<Room>();
        public AddRoomDates()
        {
            InitializeComponent();
            Init();
        }
        private async void Init()
        {
            this.rooms = await ORM.Select<Room>(Database.GetDatabase().connection, "SELECT * FROM Room", new object[0]);

            this.roomsComboBox.Items.Clear();

            foreach(var item in rooms)
            {
                this.roomsComboBox.Items.Add(item.roomNumber);
            }
        }

        private void SaveDates(object sender, RoutedEventArgs e)
        {
            List<DateTime> selectedDates = new List<DateTime>();

            foreach(var date in calendar.SelectedDates)
            {
                selectedDates.Add(date);
            }

            if(this.roomsComboBox.SelectedItem != null)
            {
                if(int.TryParse(roomsComboBox.SelectedItem.ToString(), out int roomNumber))
                {
                    var room = rooms.FirstOrDefault(x => x.roomNumber == roomNumber);
                }
                else
                {
                    return;
                }


                
            }
            else
            {
                MessageBox.Show("Musí být vybrán pokoj a dny v kalendáři!");
                return;
            }
        }
    }
}
