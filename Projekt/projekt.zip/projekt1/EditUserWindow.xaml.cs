﻿using projekt1.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace projekt1
{
    public partial class EditUserWindow : Window
    {
        User user = new User();
        Address address = new Address();

        public EditUserWindow(User u)
        {
            this.user = u;

            InitializeComponent();
            Init();

            firstNameBox.Text = user.fName;
            lastNameBox.Text = user.lName;
            phoneBox.Text = user.phone;
            emailBox.Text = user.email;
            passwdBox.Password = user.password;
            UserTypesComboBox.SelectedIndex = user.type - 1;
        }
        private async void Init()
        {
            this.address = (await ORM.Select<Address>(Database.GetDatabase().connection, "SELECT * FROM Address WHERE id = @0", user.addressId))[0];

            streetBox.Text = address.street;
            cityBox.Text = address.city;
            postalcodeBox.Text = address.postalcode;
        }

        private async void Save(object sender, RoutedEventArgs e)
        {
            if (firstNameBox.Text != "" && lastNameBox.Text != "" && phoneBox.Text != "" && emailBox.Text != "" && passwdBox.Password.ToString() != "" && streetBox.Text != "" && cityBox.Text != "" && postalcodeBox.Text != "")
            {
                address.street = streetBox.Text;
                address.city = cityBox.Text;
                address.postalcode = postalcodeBox.Text;

                await ORM.Update(Database.GetDatabase().connection, address);

                user.fName = firstNameBox.Text;
                user.lName = lastNameBox.Text;
                user.phone = phoneBox.Text;
                user.email = emailBox.Text;
                user.password = passwdBox.Password.ToString();
                user.type = UserTypesComboBox.SelectedIndex + 1;

                await ORM.Update(Database.GetDatabase().connection, user);

               
                this.Close();
            }
        }

        private void Back(object sender, RoutedEventArgs e)
        {
            this.Close();
            MenuWindow menuWindow = new MenuWindow();
            menuWindow.Show();
        }
    }
}
