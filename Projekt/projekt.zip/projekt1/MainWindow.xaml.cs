﻿using projekt1.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace projekt1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public static User loggedUser = null;
        public MainWindow()
        {
            InitializeComponent();
            Init();
        }

        private async void Init()
        {
            await Database.GetDatabase().Connect();
        }

        private async void Login(object sender, RoutedEventArgs e)
        {
            if (this.UsernameTextBox.Text == "")
            {
                MessageBox.Show("Musíte zadat emailovou adresu!");
                return;
            }
            if (this.PasswordBox.Password.ToString() == "")
            {
                MessageBox.Show("Musíte zadat heslo!");
                return;
            }

            string password = PasswordBox.Password.ToString();
            string email = UsernameTextBox.Text;

            User user = new User()
            {
                email = email,
                password = password,
            };

            if(await user.CheckLogin())
            {
                MessageBox.Show("Úspěšné přihlášení");
                loggedUser = user;
                this.Hide();
                MenuWindow menuWindow = new MenuWindow();
                menuWindow.Show();
                return;

            }
            else
            {
                MessageBox.Show("Přihlášení selhalo.");
                return;
            }
        }
    }
}
