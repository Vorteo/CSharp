﻿using projekt1.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace projekt1
{
    /// <summary>
    /// Interakční logika pro RoomsWindow.xaml
    /// </summary>
    public partial class RoomsWindow : Window
    {
        public ObservableCollection<Room> Rooms { get; set; }
        public RoomsWindow()
        {
            InitializeComponent();
            Init();

            this.DataContext = this;
        }
        private async void Init()
        {
            this.Rooms = new ObservableCollection<Room>(await Room.GetRooms());
        }

        private void AddNewDates(object sender, RoutedEventArgs e)
        {
            AddRoomDates addRoomDates = new AddRoomDates();
            addRoomDates.ShowDialog();
        }

        private void Back(object sender, RoutedEventArgs e)
        {
            MenuWindow menuWindow = new MenuWindow();
            menuWindow.Show();
            this.Close();
        }

        private void AddRoom(object sender, RoutedEventArgs e)
        {
            AddRoomWndow addRoomWndow = new AddRoomWndow();
            addRoomWndow.OnSaveRoom += x => this.Rooms.Add(x);
            addRoomWndow.ShowDialog();
        }

        private async void RemoveOrDisableRoom(object sender, RoutedEventArgs e)
        {
            Button btn = (Button)sender;
            Room r = (Room)btn.DataContext;

            List<Reservation> roomReservations = await ORM.Select<Reservation>(Database.GetDatabase().connection, "SELECT * FROM Reservation WHERE roomId = @0", r.id);

            if (roomReservations == null)
            {
                await ORM.Delete(Database.GetDatabase().connection, r);
                this.Rooms.Remove(r);
            }
            else if(r.state != "Zavřený")
            {
                r.state = "Zavřený";
                await ORM.Update(Database.GetDatabase().connection, r);
                btn.IsEnabled = false;
                CollectionViewSource.GetDefaultView(RoomsGrid.ItemsSource).Refresh();
            }
            
        }

        private void RoomDetail(object sender, RoutedEventArgs e)
        {
            Button btn = (Button)sender;
            Room r = (Room)btn.DataContext;

            EditRoomWindow editRoomWindow = new EditRoomWindow(r);
            editRoomWindow.ShowDialog();
        }
    }
}
