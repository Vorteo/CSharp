﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace projekt1.Models
{
    [Table(Name = "Address")]
    public class Address
    {
        [PrimaryKey(Skip = true)]
        public int id { get; set; }
        public string street { get; set; }
        public string city { get; set; }
        public string postalcode { get; set; }


        public bool Check()
        {
            if (postalcode.Length != 6)
            {
                return false;
            }
            for (int i = 0; i < postalcode.Length; i++)
            {
                if (postalcode[i] == ' ')
                {
                    continue;
                }
                else if (!Char.IsDigit(postalcode[i]))
                {
                    return false;
                }
            }
            return true;
        }

        public async Task Insert()
        {
            await ORM.Insert(Database.GetDatabase().connection, this);
        }
    }
}
