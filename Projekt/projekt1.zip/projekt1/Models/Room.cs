﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Security.RightsManagement;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Markup;

namespace projekt1.Models
{
    [Table(Name = "Room")]
    public class Room : INotifyPropertyChanged
    {
        [PrimaryKey(Skip = true)]
        public int id { get; set; }

        private int RoomNumber;
        public int roomNumber {
            get { return RoomNumber; } 
            set {SetField(ref RoomNumber, value, nameof(roomNumber)); }
        }

        private string roomtype;
        public string roomType {
            get {return roomtype; } 
            set {SetField(ref roomtype, value, nameof(roomType)); } 
        }

        private double pricepernight;
        public double pricePerNight {
            get {return pricepernight; } 
            set {SetField(ref pricepernight, value, nameof(pricePerNight)); }
        }

        private int maxoccupancy;
        public int maxOccupancy {
            get {return maxoccupancy; } 
            set {SetField(ref maxoccupancy, value, nameof(maxOccupancy)); } 
        }
        private string State;
        public string state {
            get { return State;}
            set { SetField(ref State, value, nameof(state));}
        }


        private void SetField<T>(ref T field, T value, string propName)
        {
            field = value;
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propName));
        }

        public static async Task<List<Room>> GetRooms()
        {
            return await ORM.Select<Room>(Database.GetDatabase().connection, "SELECT * FROM Room", new object[0]);
        }

        public async Task<bool> CheckRoom()
        {
            var room = await ORM.Select<Room>(Database.GetDatabase().connection, "SELECT * FROM Room WHERE roomNumber = @0", this.roomNumber);

            if (room == null)
            {
                return true;
            }

            return false;
        }

        public override string ToString()
        {
            return $"Číslo pokoje: {RoomNumber}, Cena za noc: {pricepernight}, Kapacita: {maxoccupancy}";
        }

        public async Task Insert()
        {
            await ORM.Insert(Database.GetDatabase().connection, this);
        }

        public event PropertyChangedEventHandler? PropertyChanged;
    }
}
