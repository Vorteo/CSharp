﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace projekt1.Models
{
    [Table(Name = "Reservation")]
    public class Reservation : INotifyPropertyChanged
    {
        [PrimaryKey(Skip = true)]
        public int id { get; set; }

        private string CheckInDate;
        public string checkInDate {
            get { return CheckInDate; }
            set { SetField(ref CheckInDate, value, nameof(checkInDate)); }
        }

        private string CheckOutDate;
        public string checkOutDate {
            get { return CheckOutDate; }
            set { SetField(ref CheckOutDate, value, nameof(checkOutDate)); } 
        }

        private string State;
        public string state {
            get { return State; }
            set { SetField(ref State, value, nameof(state)); }
        }

        private double TotalPrice;
        public double totalPrice {
            get { return TotalPrice; }
            set { SetField(ref TotalPrice, value, nameof(totalPrice)); }
        }
        [ForeignKey]
        public int roomId { get; set; }
        [ForeignKey]
        public int userId { get; set; }

        public static async Task<List<Reservation>> GetReservations()
        {
            return await ORM.Select<Reservation>(Database.GetDatabase().connection, "SELECT * FROM Reservation", new object[0]);
        }

        private void SetField<T>(ref T field, T value, string propName)
        {
            field = value;
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propName));
        }

        public event PropertyChangedEventHandler? PropertyChanged;


    }
}
