﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace projekt1.Models
{
    [Table(Name = "Availability")]
    public class Availability : INotifyPropertyChanged
    {
        [PrimaryKey(Skip = true)]
        public int id {  get; set; }
        [ForeignKey]

        private int RoomId;
        public int roomId {
            get { return RoomId; }
            set { SetField(ref RoomId, value, nameof(roomId)); }
        }

        private string Date;
        public string date { 
            get { return Date; }
            set {SetField(ref Date, value, nameof(date)); }
        }

        private int Available;
        public int available {
            get { return Available; }
            set { SetField(ref Available, value, nameof(available)); } 
        }

        private void SetField<T>(ref T field, T value, string propName)
        {
            field = value;
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propName));
        }
        public event PropertyChangedEventHandler? PropertyChanged;


        public override string ToString()
        {
            return $"{date}";
        }
    }
}
