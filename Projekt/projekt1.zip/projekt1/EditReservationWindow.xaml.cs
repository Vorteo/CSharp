﻿using projekt1.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace projekt1
{
    /// <summary>
    /// Interakční logika pro EditReservationWindow.xaml
    /// </summary>
    public partial class EditReservationWindow : Window
    {
        Reservation Reservation = new Reservation();
        User User = new User();
        Address Address = new Address();
        public EditReservationWindow(Reservation r)
        {
            this.Reservation = r;

            InitializeComponent();
            Init();
        }
        private async void Init()
        {
            priceBox.Text = Reservation.totalPrice.ToString();
            checkinBox.Text = Reservation.checkInDate.ToString();
            checkoutBox.Text = Reservation.checkOutDate.ToString();

            User = (await ORM.Select<User>(Database.GetDatabase().connection,"SELECT * FROM User WHERE id = @0", Reservation.userId))[0];
            firstNameBox.Text = User.fName.ToString();
            lastNameBox.Text = User.lName.ToString();
            emailBox.Text = User.email.ToString();
            phoneBox.Text = User.phone.ToString();

            Address = (await ORM.Select<Address>(Database.GetDatabase().connection, "SELECT * FROM Address WHERE id = @0", User.addressId))[0];
            streetBox.Text = Address.street.ToString();
            cityBox.Text = Address.city.ToString();
            postalcodeBox.Text = Address.postalcode.ToString();

        }
    }
}
