﻿using projekt1.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace projekt1
{
    public partial class ReservationsWindow : Window
    {
        public ObservableCollection<Reservation> Reservations { get; set; }
        public ReservationsWindow()
        {
            InitializeComponent();
            Init();

            this.DataContext = this;
        }
        private async void Init()
        {
            List<Reservation> tmp = await Reservation.GetReservations();
            if (tmp != null)
            {
                this.Reservations = new ObservableCollection<Reservation>(tmp);
            }
        }

        private void BackButton(object sender, RoutedEventArgs e)
        {
            this.Hide();
            MenuWindow menuWindow = new MenuWindow();
            menuWindow.Show();
        }

        private void CreateReservation(object sender, RoutedEventArgs e)
        {
            CreateReservationWindow createReservationWindow = new CreateReservationWindow();
            createReservationWindow.OnSaveReservation += x => this.Reservations.Add(x);
            createReservationWindow.ShowDialog();
        }

        private void EditReservation(object sender, RoutedEventArgs e)
        {
            Button btn = (Button)sender;
            Reservation r = (Reservation)btn.DataContext;
            EditReservationWindow editReservationWindow = new EditReservationWindow(r);
            editReservationWindow.Show();
        }

        private async void StornoReservation(object sender, RoutedEventArgs e)
        {
            Button btn = (Button)sender;
            Reservation r = (Reservation)btn.DataContext;

            if (r.state.Contains("Vytvořená"))
            {
                List<Availability> bookDays = await ORM.Select<Availability>(Database.GetDatabase().connection, "SELECT * FROM Availability WHERE roomId = @0 AND available = 0", r.roomId);
                if(bookDays == null)
                {
                    return;
                }

                DateTime start = DateTime.Parse(r.checkInDate);
                DateTime end = DateTime.Parse(r.checkOutDate);

                foreach (Availability d in bookDays)
                {
                    DateTime date = DateTime.Parse(d.date);

                    if(date >= start && date <= end)
                    {
                        d.available = 1;
                        await ORM.Update(Database.GetDatabase().connection, d);
                    }
                }

                await ORM.Delete(Database.GetDatabase().connection, r);
                this.Reservations.Remove(r);
                MessageBox.Show("Úspěšně smazená rezervace");
            }
        }
    }
}
