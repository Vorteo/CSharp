﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace projekt1
{
    public partial class MenuWindow : Window
    {
        public MenuWindow()
        {
            InitializeComponent();
        }

        private async void Exit(object sender, RoutedEventArgs e)
        {
            await Database.GetDatabase().Close();
            this.Close();
            Application.Current.Shutdown();
        }

        private void ShowUsers(object sender, RoutedEventArgs e)
        {
            this.Hide();
            UsersWindow usersWindow = new UsersWindow();
            usersWindow.Show();
        }

        private void ShowReservations(object sender, RoutedEventArgs e)
        {
            this.Hide();
            ReservationsWindow reservationsWindow = new ReservationsWindow();
            reservationsWindow.Show();
        }

        private void ShowRooms(object sender, RoutedEventArgs e)
        {
            this.Hide();
            RoomsWindow roomsWindow = new RoomsWindow();
            roomsWindow.Show();
        }
    }
}
