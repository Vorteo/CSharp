﻿using projekt1.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace projekt1
{
    public delegate void SaveRoom(Room r);
    public partial class AddRoomWndow : Window
    {
        public Room Room { get; set; } = new Room();
        public event SaveRoom OnSaveRoom;

        public AddRoomWndow()
        {
            InitializeComponent();
            this.DataContext = Room;
        }

        private async void CreateRoom(object sender, RoutedEventArgs e)
        {
            int maxocc = 0, roomNmbr = 0;
            double pricePerNight = 0;
            if (roomNumberBox.Text != "" && pricePerNightBox.Text != "" )
            {
                if(!int.TryParse(roomNumberBox.Text, out roomNmbr))
                {
                    
                    MessageBox.Show("Zadal si špatně číslo pokoje!");
                    return;
                }

                if(roomNumberComboBox.SelectedIndex == -1)
                {
                    MessageBox.Show("Musíš vybrat druh pokoje"); 
                    return;
                }

                ComboBoxItem selected = roomNumberComboBox.SelectedItem as ComboBoxItem;
                string selectedValue = selected.Content.ToString();

                if(!double.TryParse(pricePerNightBox.Text.ToString(), out pricePerNight))
                {
                    MessageBox.Show("Zadej cenu ve správném formátu xxx.x");
                    return;
                }

                Room room = new Room()
                {
                    roomNumber = roomNmbr,
                    pricePerNight = double.Parse(pricePerNightBox.Text.ToString()),
                    maxOccupancy = (int)maxOccupationSlider.Value,
                    roomType = selectedValue,
                    state = "Otevřený"
                };

                bool exists = await room.CheckRoom();
                if(exists)
                {
                    await room.Insert();
                    Room = room;
                    MessageBox.Show("Pokoj  přidán.");
                    this.OnSaveRoom?.Invoke(this.Room);
                    this.Close();
                    return;
                }

               MessageBox.Show("Pokoj již existuje.");
                    return;
            }
        }
    }
}
