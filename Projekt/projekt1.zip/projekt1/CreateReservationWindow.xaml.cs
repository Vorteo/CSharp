﻿using projekt1.Models;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace projekt1
{
    public delegate void SaveReservation(Reservation r);
    public partial class CreateReservationWindow : Window
    {
        public Reservation Reservation { get; set; } = new Reservation();
        public List<Availability> availabilities;
        public event SaveReservation OnSaveReservation;
        public CreateReservationWindow()
        {
            InitializeComponent();
            Init();

            calendar.DisplayDate = new DateTime(DateTime.Now.Year, DateTime.Now.Month, 1);
            calendar.DisplayDateStart = calendar.DisplayDate;
            calendar.DisplayDateEnd = calendar.DisplayDate.AddMonths(1).AddDays(-1);


            this.DataContext = this.Reservation;
        }
        private async void Init()
        {

            this.UserComboBox.ItemsSource = await ORM.Select<User>(Database.GetDatabase().connection, "SELECT * FROM User", new object[0]);


            this.RoomComboBox.ItemsSource = (await ORM.Select<Room>(Database.GetDatabase().connection, "SELECT * FROM Room", new object[0]))
                .Where(x => x.state != "Zavřený");

        }

        private async void CreateReservation(object sender, RoutedEventArgs e)
        {
            List<DateTime> selectedDates = new List<DateTime>(calendar.SelectedDates.Cast<DateTime>());
            foreach(DateTime date in selectedDates)
            {
                if (calendar.BlackoutDates.Contains(date))
                {
                    MessageBox.Show(date.ToShortDateString() + " je nedostupný");
                    calendar.SelectedDates.Remove(date);
                }
            }

            if ((this.RoomComboBox.SelectedItem != null) && (this.UserComboBox.SelectedItem != null) && (calendar.SelectedDates.Count > 0))
            {
                if(calendar.SelectedDates.Count == 1)
                {
                    Reservation.checkInDate = calendar.SelectedDates[0].ToString();
                    Reservation.checkOutDate = calendar.SelectedDates[0].ToString();
                }
                else
                {
                    
                    for(int i = 1; i < calendar.SelectedDates.Count; i++)
                    {
                        if ((selectedDates[i] - selectedDates[i - 1]).TotalDays != 1)
                        {
                            MessageBox.Show("Musí být zvolena sekvence dní.");
                            return;
                        }
                    }

                    Reservation.checkInDate = calendar.SelectedDates[0].ToString();
                    Reservation.checkOutDate = calendar.SelectedDates.Last().ToString();
                }

                foreach(var date in calendar.SelectedDates)
                {
                    Availability tmp = availabilities.FirstOrDefault(x => x.date.Contains(date.ToString()));
                    tmp.available = 0;
                    await ORM.Update(Database.GetDatabase().connection, tmp);
                }

                
                Room room = (Room)RoomComboBox.SelectedItem;
                User user = (User)UserComboBox.SelectedItem;

                Reservation.totalPrice = room.pricePerNight * calendar.SelectedDates.Count;
                Reservation.roomId = room.id;
                Reservation.userId = user.id;
                Reservation.state = "Vytvořená";

                await ORM.Insert(Database.GetDatabase().connection, Reservation);

                MessageBox.Show("Rezervace vytvořena");
                this.OnSaveReservation?.Invoke(this.Reservation);
                this.Close();
                return;
            }
           
        }

        private async void RoomSelectedChange(object sender, SelectionChangedEventArgs e)
        {
            Room room = (Room)RoomComboBox.SelectedItem;

            availabilities = await ORM.Select<Availability>(Database.GetDatabase().connection, "SELECT * FROM Availability WHERE roomId = @0 AND available = 1", room.id);
            if (availabilities != null)
            {

                int daysinMonth = DateTime.DaysInMonth(DateTime.Now.Year, DateTime.Now.Month);

                var dates = new DateTime[daysinMonth];

                for (int day = 1; day <= daysinMonth; day++)
                {
                    dates[day - 1] = new DateTime(DateTime.Now.Year, DateTime.Now.Month, day);
                }

                var uniqueDates = dates.Except(availabilities.Select(x => DateTime.Parse(x.date)));

                foreach (var range in uniqueDates)
                {
                    calendar.BlackoutDates.Add(new CalendarDateRange(range));
                }
            }
        }
    }
}
