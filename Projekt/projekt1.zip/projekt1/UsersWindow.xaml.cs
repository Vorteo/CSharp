﻿using projekt1.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace projekt1
{
    public partial class UsersWindow : Window
    {
        public ObservableCollection<User> Users { get; set; }
        public UsersWindow()
        {
            InitializeComponent();
            Init();
                     
            this.DataContext = this;
        }
        private async void Init()
        {
            this.Users = new ObservableCollection<User>(await User.GetUsers());       
        }

        private void EditUser(object sender, RoutedEventArgs e)
        {
            Button btn = (Button)sender;
            User u = (User)btn.DataContext;
            EditUserWindow editUserWindow = new EditUserWindow(u);
            editUserWindow.ShowDialog();
            
        }

        private void AddUser(object sender, RoutedEventArgs e)
        {
            AddUserWindow addUserWindow = new AddUserWindow();
            addUserWindow.OnSaveUser += x => this.Users.Add(x);
            addUserWindow.ShowDialog();
        }

        private void BackToMenu(object sender, RoutedEventArgs e)
        {
            this.Hide();
            MenuWindow menuWindow = new MenuWindow();
            menuWindow.Show();
        }
    }
}
