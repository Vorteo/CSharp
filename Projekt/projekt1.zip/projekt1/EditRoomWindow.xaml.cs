﻿using projekt1.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace projekt1
{
    public partial class EditRoomWindow : Window
    {
        Room Room = new Room();
        public ObservableCollection<Availability> Availabilities { get; set; }
        public List<Availability> RemoveList = new List<Availability>();

        public EditRoomWindow(Room r)
        {
            this.Room = r;

            InitializeComponent();
            Init();

            this.DataContext = this;

            roomNumberBox.Text = this.Room.roomNumber.ToString();

            int index = -1;
            for(int i = 0; i < roomTypeBox.Items.Count; i++)
            {
                if (roomTypeBox.Items[i].ToString().Contains(Room.roomType))
                {
                    index = i; break;

                }
            }

            stateBox.Text = this.Room.state.ToString();
            roomTypeBox.SelectedIndex = index;
            pricePerNightBox.Text = this.Room.pricePerNight.ToString();
            maxOccupationSlider.Value = this.Room.maxOccupancy;

        }
        private async void Init()
        {
            List<Availability> tmp = await ORM.Select<Availability>(Database.GetDatabase().connection, "SELECT * FROM Availability WHERE roomId = @0 AND available = 1", this.Room.id);
            if( tmp != null)
            {
                this.Availabilities = new ObservableCollection<Availability>(tmp);
            }
        
        }

        private async void SaveRoom(object sender, RoutedEventArgs e)
        {
            int maxocc = 0, roomNmbr = 0;
            double pricePerNight = 0;
            if (roomNumberBox.Text != "" && pricePerNightBox.Text != "")
            {
                if (!int.TryParse(roomNumberBox.Text, out roomNmbr))
                {

                    MessageBox.Show("Zadal si špatně číslo pokoje!");
                    return;
                }

                if (roomTypeBox.SelectedIndex == -1)
                {
                    MessageBox.Show("Musíš vybrat druh pokoje");
                    return;
                }

                ComboBoxItem selected = roomTypeBox.SelectedItem as ComboBoxItem;
                string selectedValue = selected.Content.ToString();

                if (!double.TryParse(pricePerNightBox.Text.ToString(), out pricePerNight))
                {
                    MessageBox.Show("Zadej cenu ve správném formátu xxx.x");
                    return;
                }

                Room.roomNumber = roomNmbr;
                Room.pricePerNight = double.Parse(pricePerNightBox.Text.ToString());
                Room.maxOccupancy = (int)maxOccupationSlider.Value;
                Room.roomType = selectedValue;
                Room.state = stateBox.Text.ToString();

                await ORM.Update(Database.GetDatabase().connection, Room);

                foreach (Availability a in RemoveList)
                {
                    await ORM.Delete(Database.GetDatabase().connection, a);
                }


                this.Close();
            }
        }
        private void RemoveDate(object sender, RoutedEventArgs e)
        {
            if (dateListBox.SelectedItem != null)
            {
                RemoveList.Add((Availability)dateListBox.SelectedItem);
                Availabilities.Remove((Availability)dateListBox.SelectedItem);
            }
        }
    }
}
