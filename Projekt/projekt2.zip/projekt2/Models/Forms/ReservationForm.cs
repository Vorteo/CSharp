﻿namespace projekt2.Models.Forms
{
    public class ReservationForm
    {
    }
}
