﻿namespace projekt2.Models.Forms
{
    public class Sort
    {
        public int orderBy { get; set; }
        public string searchText { get; set; }
        public string sortByProperty { get; set; }
    }
}
