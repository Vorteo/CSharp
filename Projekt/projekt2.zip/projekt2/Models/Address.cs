﻿using System.ComponentModel.DataAnnotations;
using System.Runtime.InteropServices;

namespace projekt2.Models
{
	[Table(Name ="Address")]
	public class Address
	{
		[PrimaryKey(Skip =true)]
		public int id {  get; set; }
		[Display(Name ="Ulice")]
		[Required(ErrorMessage = "Ulice musí být zadáná")]
		public string street { get; set; }
		[Display(Name = "Město")]
		[Required(ErrorMessage = "Město musí být zadáno")]
		public string city { get; set; }
		[Display(Name = "PSČ")]
		[Required(ErrorMessage = "PSČ musí být zadáno")]
		public string postalcode { get; set; }
	}
}
