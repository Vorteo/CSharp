﻿using System.ComponentModel.DataAnnotations;
using System.Runtime.InteropServices;

namespace projekt2.Models
{
    [Table(Name ="Availability")]
    public class Availability
    {
        [PrimaryKey(Skip =true)]
        public int id { get; set; }
        [ForeignKey]
        public int roomId { get; set; }
        [Display(Name ="Termín")]
        public string date { get; set; }
        [Display(Name ="Dostupnost")]
        public int available { get; set; }
    }
}
