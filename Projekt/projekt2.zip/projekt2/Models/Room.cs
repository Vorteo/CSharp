﻿using projekt2.Services;
using System.ComponentModel.DataAnnotations;

namespace projekt2.Models
{
	[Table(Name ="Room")]
	public class Room
	{
		[PrimaryKey(Skip =true)]
		public int id {  get; set; }
		[Display(Name ="Číslo pokoje")]
		public int roomNumber { get; set; }
		[Display(Name = "Druh pokoje")]
		public string roomType { get; set; }
		[Display(Name = "Cena za noc")]
		public double pricePerNight { get; set; }
		[Display(Name = "Kapacita")]
		public int maxOccupancy { get; set; }
		[Display(Name = "Stav")]
		public string state { get; set; }

        public static async Task<List<Room>> GetRooms()
        {
			return await ORM.Select<Room>(Database.GetDatabase().connection, "SELECT * FROM Room", new object[0]);
        }
    }
}
