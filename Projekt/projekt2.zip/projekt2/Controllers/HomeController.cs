﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using projekt2.Models;
using projekt2.Models.Forms;
using projekt2.Services;
using System.Diagnostics;
using System.Security.Cryptography.X509Certificates;

namespace projekt2.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public async void Init()
        {
            await Database.GetDatabase().Connect();
        }
        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
            Init();
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        public IActionResult Login()
        {
            if(HttpContext.Session.TryGetValue("id", out byte[] userId) != false)
            {
                return RedirectToAction("Homepage", "Home");
            }
            else
            {
                return View();
            }
        }
        [HttpPost]
        public async Task<IActionResult> Login(User user)
        {
            if (HttpContext.Session.TryGetValue("id", out byte[] userId) != false)
            {
                return RedirectToAction("Homepage", "Home");
            }
            else if(ModelState.IsValid)
            {
                var user1 = (await ORM.Select<User>(Database.GetDatabase().connection, "SELECT * FROM User WHERE email = @0 AND password = @1", user.email, user.password))?[0];
                if( user1 != null)
                {
                    HttpContext.Session.Set("id", BitConverter.GetBytes(user1.id));
                    return RedirectToAction("Homepage");
                }
                else
                {
                    ViewBag.Message = "Nepodařilo se přihlásit";
                }
            }

            return View(user);
        }

        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Login", "Home");
        }

        public IActionResult Register()
        {
            if(HttpContext.Session.TryGetValue("id", out byte[] userid) != false)
            {
                return RedirectToAction("Homepage", "Home");
            }
            else
            {
                return View();
            }
        }

        [HttpPost]
        public async Task<IActionResult> Register(RegisterUserForm form)
        {
			if (HttpContext.Session.TryGetValue("id", out byte[] userid) != false)
			{
				return RedirectToAction("Homepage", "Home");
			}
            else
            {
                if (ModelState.IsValid)
                {
                    User u = new User()
                    {
                        fName = form.fName,
                        lName = form.lName,
                        email = form.email,
                        phone = form.phone,
                        password = form.password,
                        type = 3,
                    };

                    if (await u.RegisterCheck())
                    {
                        Address a = new Address()
                        { 
                            street = form.street,
                            city = form.city,
                            postalcode = form.postalcode,
                        };

                        await ORM.Insert(Database.GetDatabase().connection, a);

                        u.addressId = a.id;
                        await ORM.Insert(Database.GetDatabase().connection, u);

                        HttpContext.Session.Set("id", BitConverter.GetBytes(u.id));
                        return RedirectToAction("Homepage");
                    }
                }
            }

            ViewBag.Message = "Špatně zadané údaje";
            return View(form);
        }

        public async Task<IActionResult> Homepage()
        {
            if(HttpContext.Session.TryGetValue("id", out byte[] userid) != false)
            {
                List<SelectListItem> options = new List<SelectListItem>()
                {
                    new SelectListItem("Vzestupně", "0"),
                    new SelectListItem("Sestupně", "1"),
                };
                ViewBag.Options = options;

                List<Room> rooms = await Room.GetRooms();
                rooms = rooms.Where(x => x.state.Contains("Otevřený")).ToList();
                ViewBag.Rooms = rooms;

                return View();
            }
            else
            {
                return RedirectToAction("Login");
            }
        }
        [HttpPost]
        public async Task<IActionResult> Homepage(Sort form)
        {
            if (HttpContext.Session.TryGetValue("id", out byte[] userid) != false)
            {
                int x = form.orderBy;

                List<SelectListItem> options = new List<SelectListItem>()
                {
                     new SelectListItem("Vzestupně", "0", x == 0 ? true : false),
                     new SelectListItem("Sestupně", "1",  x == 1 ? true : false),
                };
                ViewBag.Options = options;

                List<Room> rooms = await Room.GetRooms();

                if (x == 0)
                {
                    if (form.sortByProperty == "pricePerNight")
                    {
                        rooms = rooms.OrderBy(x => x.pricePerNight).ToList();
                    }
                    else
                    {
                        rooms = rooms.OrderBy(x => x.maxOccupancy).ToList();
                    }
                }
                else
                {
                    if (form.sortByProperty != null)
                    {
                        if (form.sortByProperty == "pricePerNight")
                        {
                            rooms = rooms.OrderByDescending(x => x.pricePerNight).ToList();
                        }
                        else
                        {
                            rooms = rooms.OrderByDescending(x => x.maxOccupancy).ToList();
                        }
                    }
                }

                ViewBag.Rooms = rooms;

                return View();
            }
            else
            {
                return RedirectToAction("Login");
            }
        }

    }
}