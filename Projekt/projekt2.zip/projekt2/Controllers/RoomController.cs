﻿using Microsoft.AspNetCore.Mvc;
using projekt2.Models;
using projekt2.Services;

namespace projekt2.Controllers
{
    public class RoomController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
        public async Task<IActionResult> Detail(int id)
        {
            var room = (await ORM.Select<Room>(Database.GetDatabase().connection, "SELECT * FROM Room WHERE id = @0", id))?[0];
            if(room == null)
            {
                return NotFound();
            }

            ViewBag.Room = room;
            return View();
        }
    }
}
