﻿using Microsoft.AspNetCore.Mvc;
using projekt2.Models;
using projekt2.Models.Forms;
using projekt2.Services;

namespace projekt2.Controllers
{
    public class UserController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
        public async Task<IActionResult> Detail()
        {
            if(HttpContext.Session.TryGetValue("id", out byte[] userid) != false)
            {
                User u = (await ORM.Select<User>(Database.GetDatabase().connection, "SELECT * FROM User WHERE id = @0", BitConverter.ToInt32(userid)))[0];
                Address a = (await ORM.Select<Address>(Database.GetDatabase().connection, "SELECT * FROM Address WHERE id = @0", u.addressId))[0];

                EditUserForm model = new EditUserForm()
                { 
                    fName = u.fName,
                    lName = u.lName,
                    phone = u.phone,
                    email = u.email,
                    type = u.type,
                    street = a.street,
                    city = a.city,
                    postalcode = a.postalcode,
                };
                return View(model);
            }
            else
            {
                return RedirectToAction("Login", "Home");
            }
        }

        [HttpPost]
        public async Task<IActionResult> Detail(int id, EditUserForm form)
        {
            if (HttpContext.Session.TryGetValue("id", out byte[] userid) != false)
            {
                User u = (await ORM.Select<User>(Database.GetDatabase().connection, "SELECT * FROM User WHERE id = @0", BitConverter.ToInt32(userid)))[0];
                Address a = (await ORM.Select<Address>(Database.GetDatabase().connection, "SELECT * FROM Address WHERE id = @0", u.addressId))[0];

                if (ModelState.IsValid)
                {
                    u.fName = form.fName;
                    u.lName = form.lName;
                    u.phone = form.phone;
                    u.email = form.email;

                    a.street = form.street;
                    a.city = form.city;
                    a.postalcode = form.postalcode;

                    await ORM.Update(Database.GetDatabase().connection, a);
                    await ORM.Update(Database.GetDatabase().connection, u);

                    return RedirectToAction("Homepage", "Home");
                }
                else
                {
                    ViewBag.Message = "Nezdařilo se uložení";
                    return View(form);
                }
            }
            else
            {
                return RedirectToAction("Login", "Home");
            }
        }
    }
}
