﻿using Microsoft.Data.Sqlite;

namespace projekt2.Services
{
    public class Database
    {
        private static Database db;
        public SqliteConnection connection { get; set; }

        public static Database GetDatabase()
        {
            if (db == null)
            {
                db = new Database();
            }

            return db;
        }

        public async Task<bool> Connect()
        {
            if (db.connection != null && db.connection.State == System.Data.ConnectionState.Open)
            {
                await db.Close();
            }
            string connString = @"Data Source=mydb.db;";
            db.connection = new SqliteConnection(connString);
            await db.connection.OpenAsync();

            return true;
        }

        public async Task Close()
        {
            await db.connection.CloseAsync();
        }

        public async Task CreateDatabase()
        {
            string sqlscript = File.ReadAllText("db-create.sql");
            if (!File.Exists("mydb.db"))
            {
                await db.Connect();

                using (SqliteCommand cmd = new SqliteCommand(sqlscript))
                {
                    cmd.CommandText = sqlscript;
                    cmd.Connection = db.connection;
                    await cmd.ExecuteNonQueryAsync();
                }
            }
            await db.Close();
        }
    }
}
