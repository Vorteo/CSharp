﻿using Microsoft.Data.Sqlite;
using projekt2.Models;
using System.Collections;
using System.Reflection;

namespace projekt2.Services
{
    public class ORM
    {
        // Vytvoreni SQL commandu
        private static SqliteCommand CreateCommand(SqliteConnection conn, string sql, params object[] parameters)
        {
            SqliteCommand cmd = new SqliteCommand(sql, conn);

            if (parameters != null && parameters.Length > 0)
            {
                for (int i = 0; i < parameters.Length; i++)
                {
                    cmd.Parameters.AddWithValue("@" + i.ToString(), parameters[i] == null ? DBNull.Value : parameters[i]);
                }
            }
            return cmd;
        }

        // Naplneni objektu daty
        private static void FillObject(object obj, SqliteDataReader reader)
        {
            int i;
            string col_name;
            object col_value;

            PropertyInfo obj_property;
            Type obj_type;

            if (obj != null && reader != null)
            {
                obj_type = obj.GetType();

                for (i = 0; i < reader.FieldCount; i++)
                {
                    col_name = reader.GetName(i);
                    obj_property = obj_type.GetProperty(col_name);

                    if (obj_property != null)
                    {
                        col_value = reader.GetValue(i);

                        // prevedeni na int32 protoze sqlite pouziva int64
                        if (col_value.GetType() == typeof(Int64))
                        {
                            col_value = Convert.ToInt32(col_value);
                        }

                        obj_property.SetValue(obj, col_value == DBNull.Value ? null : col_value);
                    }
                }
            }
        }
        // Vytvoreni casti sql prikazu, pridavani parametru 
        private static string AppendString(string originalStr, string newStr, string delimiter = " , ")
        {
            string result = originalStr;

            if (!string.IsNullOrEmpty(newStr))
            {
                if (!string.IsNullOrEmpty(originalStr))
                {
                    result = originalStr + delimiter + newStr;
                }
                else
                {
                    result = newStr;
                }
            }
            return result;
        }

        // SELECT
        public static async Task<List<T>> Select<T>(SqliteConnection conn, string sql, params object[] parameters) where T : new()
        {
            List<T> result = null;
            SqliteDataReader reader;
            SqliteCommand cmd = CreateCommand(conn, sql, parameters);

            reader = await cmd.ExecuteReaderAsync();
            if (reader.HasRows)
            {
                result = new List<T>();

                while (await reader.ReadAsync())
                {
                    T obj = new T();
                    FillObject(obj, reader);
                    result.Add(obj);
                }
            }
            await reader.CloseAsync();

            return result;
        }

        // INSERT
        public static async Task Insert(SqliteConnection conn, object obj)
        {
            Type obj_type = obj.GetType();
            string table_name = obj_type.GetCustomAttribute<TableAttribute>().Name;

            ArrayList parameters = new ArrayList();

            string property_name = null, values = null;
            int i = 0;

            foreach (var objectProperty in obj_type.GetProperties())
            {
                if (objectProperty.GetCustomAttribute<PrimaryKeyAttribute>()?.Skip == true || objectProperty.GetCustomAttribute<ForeignKeyAttribute>()?.Skip == true)
                {
                    continue;
                }
                else
                {
                    property_name = AppendString(property_name, "\"" + objectProperty.Name + "\"");
                    values = AppendString(values, "@" + i.ToString());
                    i++;

                    if (objectProperty.GetValue(obj) == null)
                    {
                        parameters.Add(DBNull.Value);
                    }
                    else
                    {
                        parameters.Add(objectProperty.GetValue(obj));
                    }
                }
            }

            string sql = "INSERT INTO " + table_name + " (" + property_name + ") values (" + values + ")";
            SqliteCommand cmd = CreateCommand(conn, sql, parameters.ToArray());
            await cmd.ExecuteNonQueryAsync();

            // Vraceni id pridaneho zaznamu, abych mohl priradit id z DB k memu objektu v aplikaci
            SqliteCommand cmd1 = new SqliteCommand("SELECT last_insert_rowid()", Database.GetDatabase().connection);
            object id = await cmd1.ExecuteScalarAsync();

            if (id != null)
            {
                foreach (var objectProperty in obj_type.GetProperties())
                {
                    if (objectProperty.GetCustomAttribute<PrimaryKeyAttribute>()?.Skip == true)
                    {

                        if (id.GetType() == typeof(Int64))
                        {
                            id = Convert.ToInt32(id);
                        }

                        objectProperty.SetValue(obj, id);
                        break;
                    }
                }
            }
        }

        // UPDATE
        public static async Task<int> Update(SqliteConnection conn, object obj)
        {
            Type obj_type = obj.GetType();
            string table_name = obj_type.GetCustomAttribute<TableAttribute>().Name;

            ArrayList values = new ArrayList();
            Dictionary<string, object> idNamesValues = new Dictionary<string, object>();


            int i = 0;
            string property_name = null;
            foreach (PropertyInfo objectProperty in obj_type.GetProperties())
            {
                if (objectProperty.GetCustomAttribute<PrimaryKeyAttribute>() != null)
                {
                    idNamesValues.Add(objectProperty.Name, objectProperty.GetValue(obj));
                    continue;
                }
                else
                {
                    property_name = AppendString(property_name, "\"" + objectProperty.Name + "\"=@" + i.ToString());
                    i++;

                    if (objectProperty.GetValue(obj) == null)
                    {
                        values.Add(DBNull.Value);
                    }
                    else
                    {
                        values.Add(objectProperty.GetValue(obj));
                    }
                }
            }

            foreach (var id in idNamesValues)
            {
                values.Add(id.Value);
            }

            string where_params = null;
            foreach (var id in idNamesValues)
            {
                where_params = AppendString(where_params, "\"" + id.Key + "\"=@" + i.ToString(), " AND ");
                i++;
            }

            string sql = "UPDATE " + table_name + " SET " + property_name + " WHERE " + where_params;
            SqliteCommand cmd = CreateCommand(conn, sql, values.ToArray());
            int result = await cmd.ExecuteNonQueryAsync();

            return result;

        }

        // DELETE
        public static async Task Delete(SqliteConnection conn, object obj)
        {
            Type obj_type = obj.GetType();
            string table_name = obj_type.GetCustomAttribute<TableAttribute>().Name;


            int i = 0;
            ArrayList values = new ArrayList();
            string where_params = null;

            foreach (PropertyInfo objectProperty in obj_type.GetProperties())
            {
                if (objectProperty.GetCustomAttribute<PrimaryKeyAttribute>() != null)
                {
                    where_params = AppendString(where_params, "\"" + objectProperty.Name + "\"=@" + i.ToString(), " AND ");
                    values.Add(objectProperty.GetValue(obj));
                    i++;
                }
                else
                {
                    where_params = AppendString(where_params, "\"" + objectProperty.Name + "\"=@" + i.ToString(), " AND ");

                    if (objectProperty.GetValue(obj) == null)
                    {
                        values.Add(DBNull.Value);
                    }
                    else
                    {
                        values.Add(objectProperty.GetValue(obj));
                    }
                    i++;
                }
            }

            string sql = "DELETE FROM " + table_name + " WHERE " + where_params;
            SqliteCommand cmd = CreateCommand(conn, sql, values.ToArray());
            await cmd.ExecuteNonQueryAsync();
        }
    }
}
